// if the user click on a link to a an item on the same page, the browser
// automatically scrolls to that element. because of the sticky header, we have
// to a scroll a little bit down (-100px)
// CR 29541
window.addEventListener('hashchange', () => {
	window.scrollBy(0, -100);
});

function elementResize(ident) {
	var w_newWidth, w_newHeight;
	var w_maxWidth = 1600, w_maxHeight = 1200;

	if (navigator.appName.indexOf("Microsoft") != -1) {
		w_newWidth = document.body.clientWidth;
		w_newHeight = document.body.clientHeight - 20;
	} else {
		var netscapeScrollWidth = 15;
		w_newWidth = window.innerWidth - netscapeScrollWidth;
		w_newHeight = window.innerHeight - netscapeScrollWidth;
	}

	if (w_newWidth > w_maxWidth) {
		w_newWidth = w_maxWidth;
	}
	if (w_newHeight > w_maxHeight) {
		w_newHeight = w_maxHeight;
	}

	var elem = document.getElementById(ident);

	elem.width = w_newWidth;
	elem.height = w_newHeight;
}

function viewerOpen(preffile) {
  var fullpath = window.location.pathname;
  fullpath = fullpath.replace('+','%2B');
  var fulldir = fullpath.substr(0, fullpath.lastIndexOf("/"));
  window.location.href = 'tpt://' + fulldir + '/' + preffile;
}

function changeVisibilty(elementIdToShow, elementIdToHide) {
	var elementToShow = document.getElementById(elementIdToShow);
	var elementToHide = document.getElementById(elementIdToHide);

	if (elementToShow) {
		var attrNode = document.createAttribute("class");
		attrNode.nodeValue = "gray-box";
		elementToShow.setAttributeNode(attrNode);
	}

	if (elementToHide) {
		var attrNode = document.createAttribute("class");
		attrNode.nodeValue = "invisible";
		elementToHide.setAttributeNode(attrNode);
	}
}

function toggleContentFunc() {
	var toggleIdList = [];
	return function(elem, duration, delay) {
		if (toggleIdList.indexOf(elem.parentNode.id) != -1) {
			// the element that is about to be toggled is already toggeling
			// visibility so return
			return;
		}
		toggleIdList.push(elem.parentNode.id);
		while (elem.nodeName === "#text") {
			elem = elem.nextSibling;
		}
		var isVisible = elem.style.display == "none" ? false : true;
		// make element visible
		var pixelPerSec = 500;
		elem.style.display = "block";
		if (!isVisible) {
			var maxSize = elem.scrollHeight;
			var currentHeight = 0;
			elem.style.display = "";
			var start = new Date();
			var id = setInterval(function() {
				resizeElem(elem, start, duration, 1, id, toggleIdList);
			}, delay || 10);
		} else {
			var currentHeight = elem.scrollHeight;
			var start = new Date();
			var id = setInterval(function() {
				resizeElem(elem, start, duration, -1, id, toggleIdList);
			}, delay || 10);
		}
	}
}

var toggleContent = toggleContentFunc();

function resizeElem(elem, startTime, duration, direction, intervalId,
		toggleIdList) {
	var timePassed = new Date() - startTime;
	var progress = timePassed / duration;
	if (progress > 1) {
		progress = 1;
	}
	var elemHeight = elem.scrollHeight;
	// if direction is negative start with 100% otherwise with 0%
	var heightPercent = direction < 0 ? 1 - progress : progress;
	var newHeight = elemHeight * heightPercent;
	var newHeightStr = newHeight + "px";
	elem.style.height = newHeightStr;
	if (progress == 1) {
		var headerElem = elem.parentNode.children[0];
		if (direction < 0) {
			elem.style.display = "none";
			headerElem.className = headerElem.className + "_closed";
		} else {
			headerElem.className = headerElem.className.replace("_closed", "");
			// set height of expanded node to auto, so expanding of childs will expand this one either
			elem.style.height = "auto";
		}
		clearInterval(intervalId);
		var index = toggleIdList.indexOf(elem.parentNode.id);
		if (index != -1) {
			toggleIdList.splice(index, 1);
		}
	}
	
}

function toggleCertainSubRows(imgElem, openByDefault) {
	// this function operates on table row elements whose class attribute has
	// only hashmarks
	// all subrows (not really subrows -> still normal rows and not nested) have
	// class with one more hashmark than the parent row so all rows with more
	// underscores will have their visibility toggled (visible <-> collapse)
	var uScoreRegEx = /^(_+)$/;
	var cellElem = imgElem.parentElement;
	var regExResult = cellElem.className.match(uScoreRegEx);
	if (regExResult.length != 2) {
		return;
	}
	var startLevel = regExResult[1].length;
	var rowElem = cellElem.parentElement;
	// set a status on the clicked element that stores the desired visibility
	// for all sub rows
	// if the status has not yet been set the clicked row is visible and the new
	// status is closed (display:"none")
	if (typeof rowElem.status === "undefinded" || rowElem.status == null
			|| rowElem.status.trim().length === 0) {
        if(openByDefault){
            rowElem.status = "table-row";
        }else{
            rowElem.status = "none";
        }
	}
	if (rowElem.status === "none") {
		rowElem.status = "table-row";
		imgElem.src = "data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAArwAAAK8AFCrDSYAAAAB3RJTUUH3wYLDDMsuFSGTAAAAPFJREFUOMvtkq9OxEAYxGf3aEgxnCEb0iY4TA3BonkAMJVYcDwA7lQlbhNEBUjgCdB4mhqeoKrpn92km26/LoJcsiFHkJj7mS+TzIyYfMCW/4f5Ik3TDyHE8TzPcM5hfRn7tgVBAKXUZ57nJ+vMjl/AOX8SQmRJkrC6rqG1xjAMmKYJjDF0XeeMMY9+ZuGLsizfoyjaI6IzIkLbtlBKgYjQ9z2MMZmUcvVrAQAURfEWx3HMOT+11oJzjnEcobV+kFLe/vTzTcOE4f51VVUv1lpYa9E0zbNzi5s/R/Q5v7zaPVyGrwyE5cHRxX12N25/bjNfQGho+5aBH20AAAAASUVORK5CYII="
	} else if (rowElem.status === "table-row") {
		rowElem.status = "none";
		imgElem.src = "data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAArwAAAK8AFCrDSYAAAAB3RJTUUH3wYLDDUdv9Ah8AAAAO9JREFUOMvd0DFOhEAYBeA3LJD9s4xAOIQ34CQmFlYUkBgKy/UAJhbcwNgYTLBRD7AHsCKxoaGzwRBCYmEIG2ZnvMDOZrHT174/X15+4M9noSuiKHoPw3BVluXbIcDQFZzzU8/zsjRNb38FTNME13WZbdvXSZLcxfHlYhYAAEopEBE45/Fut326Wt/YRwNKKZimCSEELMuC7/tnX93H69EAYwxEBCKClBJSSqg9Pze1zzEMOI4DIQTGcUTf98+f3+xi1oIgCDAMA5qmuV8uT843Lw/bWQuqqlJ1XWd5nq91d1qgbdu667rHoigy/O/8AIsxUU7/TpXMAAAAAElFTkSuQmCC"
	}
	var desiredVisibility = rowElem.status;
	var tableElem = rowElem.parentElement;
	// the column index of the cell that the user clicked; this is the cell on
	// which the class attribute is defined
	var colIndex = [].indexOf.call(rowElem.children, cellElem);
	// get the start index of all sub rows
	var currentRowIndex = [].indexOf.call(tableElem.children, rowElem) + 1;
	// apply the desired status on the sub rows
	// if the desired status is to close all sub rows it will be done no matter
	// what
	// if the desired status is to open all sub rows we restore the defined
	// status of the sub rows
	var lastRestoreLevel;
	for (var i = currentRowIndex; i < tableElem.children.length /*&& (maxAmountOfRows<0 ||i<(currentRowIndex+maxAmountOfRows))*/; i++) {
		var nextRow = tableElem.children[i];
		// we have a neighbour row here
		// check underscores
		regExResult = nextRow.children[colIndex].className.match(uScoreRegEx);
		if (regExResult.length != 2) {
			continue;
		}
		var currentLevel = regExResult[1].length;
		if (currentLevel > startLevel) {
			if (!(typeof lastRestoreLevel === "undefined")
					&& lastRestoreLevel !== null
					&& currentLevel <= lastRestoreLevel) {
				desiredVisibility = rowElem.status;
				lastRestoreLevel = null;
			}
			// found a row with more underscore so we know it's a sub row
			nextRow.style.display = desiredVisibility;
			// if we open rows we try to restore the status for a certain level
			if (rowElem.status === "table-row") {
				if (!(typeof nextRow.status === "undefined"
						|| nextRow.status == null || nextRow.status.trim().length === 0)) {
					desiredVisibility = nextRow.status;
					lastRestoreLevel = currentLevel;
				}
			}
		} else {
			// found a row with equal or less underscores so we are done with
			// toggeling visibility of child rows
			break;
		}
		nextRow = tableElem.children[currentRowIndex];
	}
}

function toggleSubRows(imgElem) {
    toggleCertainSubRows(imgElem, 1)
}
