"use strict";
var highlighted = null;
var highlightedURL = null;
var scenarioLinks = new Map();

function initNavHighlight(navFrame) {
	var arrNavLinks = null;
	if(navFrame.contentDocument !== undefined && navFrame.contentDocument !== null) {
		arrNavLinks = navFrame.contentDocument.getElementsByClassName("scenarios");
	}
	if(arrNavLinks !== null) {
		var i;
		var len = arrNavLinks.length;
		for(i = 0; i < len; ++i) {
			var key = btoa(decodeURIComponent(arrNavLinks[i].pathname));
			scenarioLinks.set(key ,arrNavLinks[i]);
		}
	}
}

function navSetActiveScen(contentFrame) {
	var calledSiteURL = contentFrame.contentWindow.location.href;
	if(calledSiteURL != null) {
		calledSiteURL = calledSiteURL.replace("file://", "");
  	calledSiteURL = btoa(decodeURIComponent(calledSiteURL));
		if(highlightedURL != calledSiteURL) {
			highlightedURL = calledSiteURL;
			if(highlighted !== null) {
			 highlighted.classList.remove("scenario-active");
			}
			if(scenarioLinks !== null) {
				if(scenarioLinks.get(calledSiteURL) !== undefined) {
					highlighted = scenarioLinks.get(calledSiteURL);
					highlighted.classList.add("scenario-active");
					highlightedURL = calledSiteURL;
				}
			}
		}
	}
}